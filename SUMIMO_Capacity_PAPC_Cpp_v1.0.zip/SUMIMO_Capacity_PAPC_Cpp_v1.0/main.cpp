
/* 
 * File:   main.cpp
 * Author: T. M. Pham, R. Farrell, and L.-N. Tran
 * Related publication: "T. M. Pham, R. Farrell and L. N. Tran, "Low-Complexity Approaches 
 * for MIMO Capacity with Per-Antenna Power Constraint," 2017 IEEE 85th Vehicular Technology Conference (VTC Spring),
 *  Sydney, Australia, 2017, pp. 1-7."
 * Alg1_fp: compute MIMO capacity by fixed point method
 * Alg2_ao: compute MIMO capacity by alternating optimization
 * Created on June 15, 2017, Updated on November 15, 2017
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <complex>
#define ARMA_DONT_USE_WRAPPER
#include <armadillo>
using namespace std;
using namespace arma;


//Algorithm 1, fixed point iteration

tuple<cx_mat, float, int, vec> Alg1_fp(cx_mat H, vec P, int nt, int nr) {
    //initialization
    double delta = 1, tmp[1000];
    float t_a = 0, CMIMO_Alg1 = 0;
    int i = 0;
    vec s;
    cx_mat U, V, Phi, S;
    mat LD = eye<mat>(nt, nt), LD_temp = eye<mat>(nt, nt);
    //fixed waterfilling
    while (delta > 1e-6) {
        LD_temp = LD;
        svd(U, s, V, H * sqrt(inv(LD_temp)));
        if (nt > nr) {
            vec tp = zeros(nt);
            vec s_tp = max(ones(nr) - pow(s, -2), zeros(nr));
            for (int j = 0; j < nr; j++) {
                tp(j) = s_tp(j);
            }

            Phi = V * (eye<mat>(nt, nt) - diagmat(tp)) * V.t();
        } else {
            Phi = V * (eye<mat>(nt, nt) - diagmat(max(ones(nt) - pow(s, -2), zeros(nt)))) * V.t();
        }

        S = inv(LD_temp) - sqrt(inv(LD_temp)) * Phi * sqrt(inv(LD_temp));

        //duality gap
        delta = abs(trace(LD_temp * (S - diagmat(P))));
        tmp[i] = delta;

        //update
        LD = inv(diagmat(P) + inv(LD_temp) * diagmat(real(Phi), 0));
        i++;
    }
    vec del(tmp, i);
    //compute capacity
    CMIMO_Alg1 += log2(abs(det(eye(nr, nr) + H * S * H.t())));
    return make_tuple(S, CMIMO_Alg1, i, del);
}

//Algorithm 2, alternating optimization

tuple<cx_mat, float, int, vec> Alg2_ao(cx_mat H, vec P, int nt, int nr) {
    //initialization
    float t_a = 0, CMIMO_Alg2 = 0, obj_temp = 1, obj = 1;
    double tmp[1000], g, g0, f0, fd, muy, delt, sum_tmp, delta = 1;
    int i = 0, r = arma::rank(H);
    vec eg, s;
    cx_mat U, V, S, Sb, Phi;
    mat LD = eye<mat>(nt, nt), LD_temp = eye<mat>(nt, nt);

    //find uplink covariance matrix
    while (delta > 1e-6) {
        svd_econ(U, s, V, H * sqrt(inv(LD)));
        eg = pow(square(s), -1);
        for (int j = r; j > 0; j--) {
            sum_tmp = 0;
            for (int k = 0; k < j; k++) {
                sum_tmp += eg(k);
            }
            muy = (sum_tmp + sum(P)) / (j);
            if (muy - eg(j - 1) > 0) {
                break;
            }
        }
        Sb = U * diagmat(max(muy - eg, zeros(r, 1))) * U.t();

        obj_temp = obj;
        obj = log2(abs(det(LD + + H.t() * Sb * H))) - log2(abs(det(LD)));
        if (i > 0) {
            delta = abs(obj - obj_temp);
            tmp[i - 1] = delta;
        }

        //find noise covariance
        Phi = inv(LD + H.t() * Sb * H);
        vec temp = real(Phi.diag());
        g0 = 0.001;
        g = g0;
        delt = 1;
        while (delt > 1e-6) {
            g0 = g;
            f0 = sum(P.t() * pow(temp + g*P, -1)) - sum(P);
            fd = -(sum(P.t() * pow(temp + g*P, -2)));
            g = g0 - f0 / fd;
            delt = abs(g - g0);
        }
        if (g < 0) {
            g = 0;
        }
        LD_temp = LD;
        vec temp1 = pow(temp + g*P, -1);
        LD = diagmat(temp1);
        i++;
    }
    vec del(tmp, i - 1);
    //compute downlink covariance and capacity
    S = sqrt(inv(LD)) * V * U.t() * Sb * U * V.t() * sqrt(inv(LD));
    CMIMO_Alg2 = obj;
    return make_tuple(S, CMIMO_Alg2, i - 1, del);
}

int main(int argc, char** argv) {
    //initialization
    double delta = 1, Pt = 1;
    int iter1, iter2;
    float CMIMO_Alg1 = 0, CMIMO_Alg2 = 0;
    int nt = 4, nr = 8;
    vec del1, del2, P, s;
    cx_mat S1, S2;
    cx_mat H = randn(nr, nt) + randn(nr, nt)*1i;
    P = vec(Pt / nt * ones(nt));

    //call algorithms 1 and 2
    tie(S1, CMIMO_Alg1, iter1, del1) = Alg1_fp(H, P, nt, nr);
    tie(S2, CMIMO_Alg2, iter2, del2) = Alg2_ao(H, P, nt, nr);

    //print parameters and results
    cout << "No. of transmit antennas: " << nt << endl;
    cout << "No. of receive antennas: " << nr << endl;
    cout << "Per-antenna power constraint: " << P << endl;
    cout << "Algorithm 1, fixed point" << endl;
    cout << "CMIMO=" << CMIMO_Alg1 << endl;
    cout << "Number of iterations=" << iter1 << endl;
    cout << "Duality gap=" << del1 << endl;
    cout << "Algorithm 2, alternating optimization" << endl;
    cout << "CMIMO=" << CMIMO_Alg2 << endl;
    cout << "Number of iterations=" << iter2 << endl;
    cout << "Duality gap=" << del2 << endl;


    return 0;
}

